#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <cmath>
#include "suleyman.berber_Berber_Suleyman_hw5_myVector.h"

using namespace std;
        
// Default constructor
template <typename T1, typename T2>
myVector<T1, T2>::Iterator::Iterator(myVector & vec): myvec(vec), myCurrent(0) {}

// Copy constructor
template <typename T1, typename T2>
myVector<T1, T2>::Iterator::Iterator(const Iterator& copy)
 : myvec(copy.myvec) {
    this->myCurrent = copy.myCurrent;
}

//  The Init function resets the iterator to the beginning of the vector.
template <typename T1, typename T2>
void myVector<T1,T2>::Iterator::Init() {
  myCurrent = 0;
}

// The HasMore function checks if there are more elements to iterate over.
template <typename T1, typename T2>
bool myVector<T1,T2>::Iterator::HasMore() const {
    return (myCurrent < myvec.data.size());
}

// The Current function returns a reference to the current pair.
template <typename T1, typename T2>
myVector<T1, T2>::pair& myVector<T1,T2>::Iterator::Current() {
    return myvec.data[myCurrent];
}

// The Next function moves the iterator to the next element.
template <typename T1, typename T2>
void myVector<T1,T2>::Iterator::Next() {
  myCurrent += 1;
}

// Find function search a key in vector, if it finds, it returns true else it returns false
template <typename T1, typename T2>
bool myVector<T1,T2>::Iterator::find(T2 old_key, myVector & vec){
    bool flag = false;
    
    for (Init(); HasMore(); Next()) {
        if (Current().key == old_key) {
            flag = true;
            break;
        }
    }
    return flag;
}

// replaceKey function takes a new key (new_key) and replaces the key of the current pair pointed by the iterator with the new key.
template <typename T1, typename T2>
void myVector<T1,T2>::Iterator::replaceKey(T2 new_key){
    Current().key = new_key;
}

// printVector function prints the values and keys of all pairs in the vector using the iterator.
template <typename T1, typename T2>
void myVector<T1,T2>::Iterator::printVector(){
    for (Init(); HasMore(); Next()) {
        cout << "Value: " << Current().value << ", Key: " << Current().key << endl;
    }
}

// The removed function remove the pair which has a value from the vector
template <typename T1, typename T2>
void myVector<T1,T2>::Iterator::removed(T1 value){
    int i = 0;
    for (Init(); HasMore(); Next()) {
        if (Current().value == value) {
            myvec.data.erase(myvec.data.begin()+i);
            break;
        }
        i++;
    }
}

// copy constructor
template <typename T1, typename T2>
myVector<T1, T2>::myVector(myVector &copy){
    Iterator itr(copy);
    for (itr.Init(); itr.HasMore(); itr.Next()){
        pair temp(itr.Current().value, itr.Current().key);
        data.push_back(temp);
    }
    vector_name = copy.vector_name;
}

// Begin function creates and returns an iterator pointing to the beginning of the vector.
template <typename T1, typename T2>
typename myVector<T1, T2>::Iterator myVector<T1, T2>::begin(){
    Iterator itr(*this);
    return itr;
}

// It takes a key as a parameter and returns a pointer to the value associated with that key. If the key is not found, it returns a nullptr.
template <typename T1, typename T2>
T1 * myVector<T1, T2>::operator[] (const T2 & key){
    Iterator itr(*this);
    for (itr.Init() ; itr.HasMore(); itr.Next()) {
        if (itr.Current().key == key){
            T1 *temp = &(itr.Current().value);
            return temp;
        }
    }
    return nullptr;
}

template <typename T1, typename T2>
void myVector<T1, T2>::operator =(myVector & target){
    
    Iterator itr(target);
    for (itr.Init() ; itr.HasMore(); itr.Next()) {
        push_back(itr.Current().value, itr.Current().key);
    }
}

// This check_equal operator compares the content of two vectors for equality. It returns true if both vectors have the same size and contain the same key-value pairs; otherwise, it returns false.
template <typename T1, typename T2>
bool myVector<T1, T2>::operator ==(myVector & target){
    
    bool flag = true;
    if(data.size() != target.data.size())
        flag = false;
    
    Iterator itr1(*this), itr2(target);
    for (itr1.Init(); itr1.HasMore(); itr1.Next()) {
        
        if (itr1.Current().key != itr2.Current().key) {
            flag = false;
            break;
        }
        if (itr1.Current().value != itr2.Current().value) {
            flag = false;
            break;
        }
        itr2.Next();
    }
    return flag;
}

// The getName function returns the name of the vector.
template <typename T1, typename T2>
string myVector<T1, T2>::getName(){
    return vector_name;
}

// The setName function sets the name of the vector.
template <typename T1, typename T2>
void myVector<T1, T2>::setName(string n){
    vector_name = n;
}

// The push_back function adds a new key-value pair to the vector.
template <typename T1, typename T2>
void myVector<T1, T2>::push_back(const T1 & value, const T2 & key){
    pair temp(value, key);
    data.push_back(temp);
}

// The remove function removes all pairs with a specified key from the vector.
template <typename T1, typename T2>
void myVector<T1, T2>::remove(const T2 & key){
    
    int i = -1;
    Iterator itr(*this);
    for (itr.Init(); itr.HasMore(); itr.Next()) {
        i++;
        if (itr.Current().key == key)
            data.erase(data.begin()+i);
    }
}

// The isEmpty function returns true if the vector is empty; otherwise, it returns false.
template <typename T1, typename T2>
bool myVector<T1, T2>::isEmpty(){

    if(data.size() == 0)
        return true;
    else
        return false;
}

// Depending on the type of the values in the vector, the process_data function either finds and prints the most frequent character and word (if the values are strings) or calculates and prints mean, median, standard deviation, max, and mode (if the values are numbers).
template <typename T1, typename T2>
void myVector<T1, T2>::process_data(){
    
    Iterator itr(*this);
  
    if constexpr (is_same<T1, string> :: value){
        find_frequent_char_word(itr);
    }
    else if constexpr (is_same<T1, double> :: value || is_same<T1, int> :: value){
        
        double mean = find_mean(itr);
        double deviation = find_deviation(itr, mean);
        double max = find_max(itr);
        double mode = find_mode(*this);
        cout << "Mean: " << mean << endl;
        cout << "Median: " << find_median(*this) << endl;
        cout << "Standard Deviation: " << deviation << endl;
        cout << "Max: " << max << endl;
        cout << "Mode: " << mode << endl;
    }
}

// find_frequent_ch function counts the frequency of each character in the words of the vector and finds the most frequent character and word.
template <typename T1, typename T2>
void myVector<T1, T2>::find_frequent_char_word(Iterator itr) {

    const int size = 128;
    const int data_size = data.size();
    int charFrequency[size] = { 0 };
    vector<int> wordFrequency(data_size, 0);
    Iterator itr1(itr);
    itr1.Next();

    // This for loop adds the counts of the characters to array
    for (itr.Init(); itr.HasMore(); itr.Next()) {

        string word = itr.Current().value;
        int len = word.length();
        for (int i = 0; i < len; i++) {
            char ch = word[i];
            charFrequency[ch - 0]++;
        }
    }
    
    // This for loop adds the counts of the words to array
    int temp = 0;
    for (itr.Init(); itr.HasMore(); itr.Next()) {

        int num = 1;
        itr1.Init();
        for (int i = -1; i<temp ; i++)
            itr1.Next();
        while (itr1.HasMore()){
            if(itr1.Current().value == itr.Current().value)
                num++;
            itr1.Next();
        }
        wordFrequency[temp] = num;
        temp++;
    }
    
    int maxCharCount = 0;
    for (int c = 0; c < 128; c++){
        if (charFrequency[c] > maxCharCount)
            maxCharCount = charFrequency[c];
    }
    vector<int> frequented_chars;
    
    for (int i = 0; i < 128; i++) {
        if (charFrequency[i] == maxCharCount) {
            maxCharCount = charFrequency[i];
            frequented_chars.push_back(i);
        }
    }
    
    int min_char = frequented_chars[0];
    char mostFrequentChar = char(min_char);
    if (frequented_chars.size() != 1){
        for (int a = 1; a < frequented_chars.size(); a++){
            if (min_char > frequented_chars[a])
                min_char = frequented_chars[a];
        }
        mostFrequentChar = char(min_char);
    }
    
    int maxWordCount = 0;
    for (int d = 0; d < data_size; d++){
        if (wordFrequency[d] > maxWordCount)
            maxWordCount = wordFrequency[d];
    }
    itr.Init();
    vector<string> frequented_words;
    
    for (int i = 0; i < data_size; i++) {
        if (wordFrequency[i] == maxWordCount)
            frequented_words.push_back(itr.Current().value);
        itr.Next();
    }
    
    string mostFrequentWord = frequented_words[0];
    if (frequented_words.size() != 1){
        for (int b = 1; b < frequented_words.size(); b++){
            if(mostFrequentWord > frequented_words[b])
                mostFrequentWord = frequented_words[b];
        }
    }
    cout << "Most Frequent Character: \'" << mostFrequentChar << "\' (Frequency: " << maxCharCount << ")" << endl;
    cout << "Most Frequent Word: \"" << mostFrequentWord << "\" (Frequency: " << maxWordCount << ")" << endl;
}

// find_mean functions finds the mean of the vector
template <typename T1, typename T2>
double myVector<T1, T2>::find_mean (Iterator itr){
    double sum = 0;
    Iterator copy(itr);
    
    for (copy.Init() ; copy.HasMore(); copy.Next())
        sum += copy.Current().value;
    return sum/data.size();
}

// find_median functions finds the median of the vector
template <typename T1, typename T2>
double myVector<T1, T2>::find_median (myVector & copy){
    
    vector <T1> sorted;
    myVector temp(copy);
    Iterator sort(temp);
    Iterator s(sort);
    while (sort.HasMore()) {

        T1 min = sort.Current().value;
        s.Init();
        s.Next();
        while (s.HasMore()){
            if(min > s.Current().value){
                min = s.Current().value;
            }
            s.Next();
        }
        sort.removed(min);
        sorted.push_back(min);
        sort.Init();
    }
    
   if (sorted.size()%2 == 0)
       return (((sorted[sorted.size()/2-1] + sorted[sorted.size()/2])/2));
   
   else
       return sorted[sorted.size()/2];
}

// find_deviation functions finds the standard deviation of the vector
template <typename T1, typename T2>
double myVector<T1, T2>::find_deviation (Iterator itr, double mean){
    
    double sum = 0;
    for (itr.Init(); itr.HasMore(); itr.Next())
        sum += (itr.Current().value-mean)*(itr.Current().value-mean);
    return sqrt(sum / data.size() );
}

// find_mode functions finds the mode of the vector
template <typename T1, typename T2>
double myVector<T1, T2>::find_mode (myVector & copy){
    
    vector <T1> sorted;
    myVector temp(copy);
    Iterator sort(temp);
    Iterator s(sort);
    while (sort.HasMore()) {

        T1 min = sort.Current().value;
        s.Init();
        s.Next();
        while (s.HasMore()){
            if(min > s.Current().value){
                min = s.Current().value;
            }
            s.Next();
        }
        sort.removed(min);
        sorted.push_back(min);
        sort.Init();
    }

    double current_mode = sorted[0];
    int maxCount = 1;
    
    for (int i = 0; i < sorted.size(); i++) {
        T1 curr_element = sorted[i];
        int currentCount = 1;
        
        for (int j = i+1; j < sorted.size(); j++){
            if(sorted[i] == sorted[j])
                currentCount++;
        }
        
        if (currentCount > maxCount) {
            current_mode = curr_element;
            maxCount = currentCount;
        }
    }
    return current_mode;
}

// find_max functions finds the max of the vector
template <typename T1, typename T2>
double myVector<T1, T2>::find_max (Iterator itr){

    double max = itr.Current().value;
    itr.Next();
    while (itr.HasMore()) {
        if(max < itr.Current().value)
            max = itr.Current().value;
        itr.Next();
    }
    return max;
}
