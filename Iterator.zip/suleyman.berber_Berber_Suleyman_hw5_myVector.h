#ifndef _MYVECTOR_H
#define _MYVECTOR_H

template <typename T1, typename T2>
class myVector {
public:
    
    // It represents a key-value pair.
    struct pair {
        T1 value;
        T2 key;
        
        pair (T1 val, T2 k)
        : value(val), key(k) {}
    };
    
    class Iterator {
    public:
        
        // Default constructor
        Iterator(myVector & vec);
        
        // Copy constructor
        Iterator(const Iterator& copy);
        
        //  The Init function resets the iterator to the beginning of the vector.
        void Init();
        
        // The HasMore function checks if there are more elements to iterate over.
        bool HasMore() const;
        
        // The Current function returns a reference to the current pair.
        pair & Current();
        
        // The Next function moves the iterator to the next element.
        void Next();
        
        // Find function search a key in vector, if it finds, it returns true else it returns false
        bool find(T2 old_key, myVector & vec);
        
        // replaceKey function takes a new key (new_key) and replaces the key of the current pair pointed by the iterator with the new key.
        void replaceKey(T2 new_key);
        
        // printVector function prints the values and keys of all pairs in the vector using the iterator.
        void printVector();
        
        // The removed function remove the pair which has a value from the vector
        void removed(T1 value);
        
    private:
        myVector & myvec; // A reference to a myVector object.
        int myCurrent; // An integer representing the current position of the iterator in the vector.
        
    };
    
    // default constructor
    myVector (){}

    // copy constructor
    myVector(myVector &copy);

    // Begin function creates and returns an iterator pointing to the beginning of the vector.
    Iterator begin();

    // It takes a key as a parameter and returns a pointer to the value associated with that key. If the key is not found, it returns a nullptr.
    T1 * operator[] (const T2 & key);
    
    // This operator copy target object the this object
    void operator =(myVector & target);
    
    // This check_equal operator compares the content of two vectors for equality. It returns true if both vectors have the same size and contain the same key-value pairs; otherwise, it returns false.
    bool operator ==(myVector & target);
   
    // The getName function returns the name of the vector.
    std::string getName();
 
    // The setName function sets the name of the vector.
    void setName(std::string n);
    
    // The push_back function adds a new key-value pair to the vector.
    void push_back(const T1 & value, const T2 & key);
    
    // The remove function removes all pairs with a specified key from the vector.
    void remove(const T2 & key);
    
    // The isEmpty function returns true if the vector is empty; otherwise, it returns false.
    bool isEmpty();
    
    // Depending on the type of the values in the vector, the process_data function either finds and prints the most frequent character and word (if the values are strings) or calculates and prints mean, median, standard deviation, max, and mode (if the values are numbers).
    void process_data();
    
    // find_frequent_ch function counts the frequency of each character in the words of the vector and finds the most frequent character and word.
    void find_frequent_char_word(Iterator itr);
    
    // find_mean functions finds the mean of the vector
    double find_mean (Iterator itr);
    
    // find_median functions finds the median of the vector
    double find_median (myVector & copy);
    
    // find_deviation functions finds the standard deviation of the vector
    double find_deviation (Iterator itr, double mean);
    
    // find_mode functions finds the mode of the vector
    double find_mode (myVector & copy);
 
    // find_max functions finds the max of the vector
    double find_max (Iterator itr);

        
private:
    std::vector<pair> data; // A vector of pair representing the key-value pairs.
    std::string vector_name; // name of the vector
    
};

#include "suleyman.berber_Berber_Suleyman_hw5_myVector.cpp"
#endif
